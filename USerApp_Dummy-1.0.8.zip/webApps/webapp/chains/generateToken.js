define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class generateToken extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $application, $constants, $variables, $functions } = context;

     const jwt =  await $functions.getUsernameFromJwt($variables.jwt);

      $variables.user = jwt ? jwt : $application.user.username;
    }
  }

  return generateToken;
});
